/*
 *    Created by Chenxi 23/6/2017
 * */

module.exports =  {
    gulpHdName: 'list',
    gulpCategory: {
        'index': '上传列表'
    }
};